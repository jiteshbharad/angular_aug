import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-details',
  templateUrl: './add-details.component.html',
  styleUrls: ['./add-details.component.css']
})
export class AddDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
