import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {

  details={rollno:0,fname:'',lname:'',email:'',marks:0,address:{
    hno:0, street:'',city:'',state:''
  }};

  selectedRollno = 0;

  constructor(private studentService:StudentService,
            private route : ActivatedRoute
    ) { }

  ngOnInit(): void {
    
    this.route.params.subscribe((obj:any)=>{
      this.fetchDetails(obj['rollno']);
    })
  }

  fetchDetails(rollno:number)
  {
    this.studentService.getByRollno(rollno).subscribe((result:any)=>{
      this.details= result;
      console.log(result);      
    });
  }
}
