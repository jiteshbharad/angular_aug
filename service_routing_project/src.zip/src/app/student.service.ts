import { formatDate } from '@angular/common';
import { Injectable } from '@angular/core';
import {from,Observable} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  students = [
    {fname : 'john',lname:'paul',email:'jp@gmail.com',rollno:1,marks:87,address:{hno:12,street:'lane 12',city:'pune',state:'MH'}},
    {fname : 'sohan',lname:'sharma',email:'ss@gmail.com',rollno:2,marks:89,address:{hno:12,street:'abc',city:'noida',state:'UP'}},
    {fname : 'david',lname:'verghese',email:'dv@gmail.com',rollno:3,marks:99,address:{hno:12,street:'def',city:'bangalore',state:'KA'}},
    {fname : 'nisha',lname:'kale',email:'nk@gmail.com',rollno:4,marks:65,address:{hno:12,street:'pqr',city:'hyderabad',state:'TS'}}
  ]
  constructor() { }

  getAllStudents()
  {
    return from(this.students);
  }

  getByRollno(rollno:number)
  {
   return  new Observable((subscriber)=>{    
    let targetStdArr = this.students.filter((std)=>{
      return rollno == std.rollno;
    });
    subscriber.next(targetStdArr[0])
    });
  }
}
