import { Component, OnInit } from '@angular/core';
import { StudentService } from '../student.service';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  constructor(private studentService:StudentService,
              private router:Router) { }

  students:any[]=[];

  ngOnInit(): void {
    this.fetch();
  }

  goToDetails(rollno:number)
  {
    this.router.navigate(['details',rollno]);
  }

  fetch()
  {
    this.studentService.getAllStudents()
                          .subscribe((resp)=>{
                            this.students.push(resp);
                          });
  }

}
