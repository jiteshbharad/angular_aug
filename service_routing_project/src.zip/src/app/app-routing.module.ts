import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { ListComponent } from './list/list.component';
import { AddDetailsComponent } from './add-details/add-details.component';
import { NotFoundComponent } from './not-found/not-found.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { DetailsComponent } from './details/details.component';

const routes: Routes = [
  {path:'',redirectTo:'home',pathMatch:'full'},
  // {path:'',component:HomeComponent},
  {path:'home',component:HomeComponent , children:[
                                                {path:'about',component:AboutComponent},
                                                {path:'contact',component:ContactComponent}
                                              ]},
  {path:'list',component:ListComponent},
  {path:'add',component:AddDetailsComponent},  
  {path:'details/:rollno',component:DetailsComponent},
  {path:'**',component:NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }





















